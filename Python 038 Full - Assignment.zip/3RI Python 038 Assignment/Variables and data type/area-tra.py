# write the program for calculating the area of rectangle

length = 12         # length of rectangle
breadth = 6         # breadth of rectangle

formula = length * breadth   # formula for calculating the area of rectangle

print("area of rectangle :" , formula)          # print the area of rectangle

'''
OUTPUT ---> area of rectangle : 72
'''
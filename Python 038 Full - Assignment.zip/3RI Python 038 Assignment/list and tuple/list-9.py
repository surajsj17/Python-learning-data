# write the program to take input from user as string covert first letter in uppercase

string = input(" Enter the string : ")
new_string = string.title()
print("The entered string : ",new_string)

'''
OUTPUT - The entered string :  Stop And Smell The Roses
'''
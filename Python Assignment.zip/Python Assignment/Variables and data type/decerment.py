# write the program for take the input from the user and decerment by 3

number = float(input("Enter the number for the decerment by 3 :"))   # Taking input from the user
number = number - 3             #decerment by 3
print ("Number :" ,number)

'''
Enter the number for the decerment by 3 :1
Number : -2.0
'''
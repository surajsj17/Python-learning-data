# write the program to print all even numbers in between 1 to 20

print ("The even number between 1 and 20")
print()
for i in range(1,20+1):
    if i % 2 == 0:
        print ("The even number :" ,i)

'''
OUTPUT - 
The even number between 1 and 20

The even number : 2
The even number : 4
The even number : 6
The even number : 8
The even number : 10
The even number : 12
The even number : 14
The even number : 16
The even number : 18
The even number : 20
'''
      
#write the python program take input from user and convert the temperature from Fahrenheitc to celsius ?
#Formula - C = (f-32)*5/9

#Taking Input from user.

fahrenhetic = float(input("Enter temperature in Fahrenheit :")) #fahrenhetic is a variable

#Formula for celsius conversion from fahrenhetic 
celsius = (fahrenhetic-32)*5/9                                
print ("Temperature in Celsius : ", celsius)    #output celsius


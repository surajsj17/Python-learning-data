# write the program and display the employee details

employee_name = "BOB"                   # employee details 
employee_ID =  102
employee_age = 24
employee_phone = 9511864548
employee_address = "UK"
company_name = "PickupBiz"


print("*" * 20)
print ("Employee details")
print("*" * 20)

print("Employee Name :",employee_name)
print("Employee ID :",employee_ID)
print("Employee Age : ",employee_age)
print("Employee phone : ", employee_phone)
print("Employee address : ", employee_address)
print("Company Name :",company_name)

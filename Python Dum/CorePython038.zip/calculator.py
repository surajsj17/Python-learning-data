# calc --> module
l1 = [10,20,30,40,50]

def addition(a,b):
    return a+b

def sqrt(a):
    return a**0.5

def square(a):
    return a**2
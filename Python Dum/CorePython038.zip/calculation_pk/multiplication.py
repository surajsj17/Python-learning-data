def multi1(a, b):
    return a * b

def multi2(a, b, c):
    return a * b * c

def multi3(a, b, c, d):
    return a * b * c * d
# print hello world
# print() is inbuild function or method

print ("Hello world!")
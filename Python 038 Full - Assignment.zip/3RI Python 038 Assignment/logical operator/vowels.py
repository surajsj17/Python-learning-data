# write the program to check entered letter is vowels or not ? using logical operators


string = input(" Enter the letter : ")

if string == "a" or string == "e" or string == "i" or string == "o" or string == "u" :
    print ("It's a vowels letter",string)
else:
    print ("It's not a vowels letter ",string)
    
'''
OUTPUT - 
 Enter the letter : a
It's a vowels letter a
'''
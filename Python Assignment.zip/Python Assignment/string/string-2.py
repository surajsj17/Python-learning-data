# write the program to print 3 characters from the entered string

string = input("Enter the string : ")
char = (string[2:3:])
print("The 3rd character of string = ", char)
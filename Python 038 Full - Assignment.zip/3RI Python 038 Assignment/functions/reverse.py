# write the program to reverse the String with function


string = "the python is programming language"

def reverse(s):
        reverse_string = s[::-1]
        return reverse_string
print (reverse(string))

'''
OUTPUT:
egaugnal gnimmargorp si nohtyp eht
'''
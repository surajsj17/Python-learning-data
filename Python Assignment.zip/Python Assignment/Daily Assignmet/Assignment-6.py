# write the program for check the entered number is positive or negative

number = int(input("Enter the number :"))
if number < 0 :
    print ("It's negative number :",number)
else:
    print("It's positive number :",number)
    
'''
OUTPUT -    
Enter the number :2
It's positive number : 2

Enter the number :-1
It's negative number : -1
'''
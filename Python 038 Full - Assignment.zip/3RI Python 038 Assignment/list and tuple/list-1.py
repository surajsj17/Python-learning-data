# # write the program to check the entered employee name is existing or not 
# emp_name = input("Enter the name : ")
name = ["jenny","bob","virat","rohit"]
if emp_name in name:
    print ("The Employee name is Matching : " ,emp_name)
else:
    print ("The Employee name is Not Matching : " ,emp_name)
'''
OUTPUT = Enter the name : virat
         The Employee name is Matching :  virat
'''    

    




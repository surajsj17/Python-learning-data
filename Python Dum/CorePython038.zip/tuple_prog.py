# tuple : () optional
# immutable,ordered,duplicates are allowed..
# we can store any type of data.
t1 = (1,2,3,"python")

t2 = 20,30,40,50

# single value  in tuple: t = (20)
t = 20  # int
t2 = ("python")  # str

t = 20, # tuple
t2 = ("python",) # tuple

l1 = [10,20,30,20,40]
l1 = tuple(l1)
print(l1)

print(dir(tuple))


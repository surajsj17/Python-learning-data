def add1(a,b):
    return a+b

def add2(a,b,c):
    return a+b+c

def add3(a,b,c,d):
    return a+b+c+d

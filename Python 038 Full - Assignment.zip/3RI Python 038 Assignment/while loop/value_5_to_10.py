# write the program to print the value from 5 to 15

# counter = 5
# while counter <= 15:
#     print(counter)
#     counter = counter + 1


num = int(input("Enter the number :"))
num1=int(input("Enter the second number :"))

counter = num

while counter <= num1:
    print(counter)
    counter = counter + 1
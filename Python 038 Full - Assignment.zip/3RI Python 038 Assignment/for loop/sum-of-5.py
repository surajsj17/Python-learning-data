# write the program to print sum of first 5 possitive number

total_num = 0

for i in range(1,6):
    total_num = total_num + i
    print(total_num)


#print() function is used to print the output to the console
print("hello we learn python language")

"""print("hello all gm.")
print("python")
print("python is simple") """


#comment : used to explain the code and make it more readable.
# It is not executed by the interpreter
#single line : #
# multi line : ''' ''' or """ """

# variables : used to store the data
# Rules for variable names:
# A variable name must start with a letter or the underscore character
# A variable name cannot start with a number
# A variable name can only contain alpha-numeric characters and underscores (A-z, 0-9, and _ )
# Variable names are case-sensitive (age, Age and AGE are three different variables)

a = "hello"  # string
b = 10 # integer int
c = 10.5 # float
name = "john"

emp_details = "john king"
Age = 25
age = 30

print(a)
print(age) # 30
print(Age)
print(b)

#type() : used to get the data type of the variable or object
print(type(a))

print(type([1,2,3,4,5]))
print(type("hello"))
print(type(True))


# how to assign multiple values to multiple variables.
x  = 10
y = 20
z  = "hello"
x,y,z = 10,20,"hello"
#a,b,c ---> "python programming"

# assign multiple variables to same value
a=b=c="python programming"
print(a)
print(b,c)



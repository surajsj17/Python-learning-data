#write a python program to take the radius of a circle from the user and calculate the area of circle ?
#formula : area = pi*r*r

pi = 3.14   # pi value 3.14 need to declare first

# input from user 
radius = int(input("Enter the radius of circle to calculate the area of circle :"))

#formula to calculate the area of circle
area = pi*radius*radius

print ("Area of circle :" , area ) 
# # input(): its a function that takes input from the user
# print(50 +20)
# x = 20
# y = 30
# z = x+y 
# print(z)
# # wap to take  2 int numbers from the user and print the sum of those numbers
# a = input("Enter the first number:") # 30 # str '30'
# b = input("Enter the second number:") #10  # str '10'
# sum = a+b # 30+10 = 40 
# print(sum) # 40  # 3010


# #  type casting : converting one data type to another 
# #data type
# #int(input("msg")) # converting to integer
# # wap to take  2 int numbers from the user and print the sum of those numbers
# a = int(input("Enter the first number:")) # 30 # str '30' -->30
# b = int(input("Enter the second number:")) #10  # str '10' --> 10
# sum = a+b # 30+10 = 40 
# print(sum) # 40  # 3010
# print("addition of",a,"and",b,"is",sum)

# # wap to take employee details from the user and 
# #print the details
# # name, age, salary (float), address
# # sample output:
# # Employee details
# # name : john
# # age : 25
# # Salary : 25000.0
# # address : bangalore
# name = input("Enter the name:")
# age = int(input("Enter the age:"))
# sal = float(input("Enter the salary:"))
# add = input("Enter the address:")
# print("Employee details")
# print("your name is:",name)
# print("you are",age,"years old")
# print("your salary is:",sal)
# print("you are from:",add)

#  operators : used to perform operations on 
#variables and values
# Arithmetic operators : +,-,*,/,%,//,**
a = 20 # int
b = 5 # int
print("Addition",a+b) # 25
print("subtraction",a-b) # 15
print("multiplication",a*b) # 100
print("Division (quotient float)",a/b) # 4.0
print(" Floor Division (quotient int)",a//b) # 4
print("Modulus (remainder)",a%b) # 0
print("Exponentiation (power)",a**b) # 20^5 = 3200000


#1. write a python program to take 2 numbers from the user
# and perform all arithmetic operations on those numbers.

#2. write a python program to convert the temperature from
# fahrenheit to celsius. formula : c = (f-32)*5/9
# f = 98.6
# c = ?

#3. write a python program to take the radius of a circle
# from the user and calculate the area of the circle.
# formula : area = pi*r*r

# relational operator

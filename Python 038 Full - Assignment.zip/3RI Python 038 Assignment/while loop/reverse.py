# write a program to print number 10 to 1

counter = 10
while counter >= 1:
    print(counter)
    counter = counter - 1
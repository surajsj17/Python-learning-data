# write the program and calculate the cube of entered number

number = float(input("Enter number to calculate the cube of entered number : "))   # input  number is 20.02

cube = number ** 3                      #cube calculated

print ("The cube of entered number : " ,cube)

'''
OUTPUT - Enter number to calculate the cube of entered number : 20.02
         The cube of entered number :  8024.024007999999
'''
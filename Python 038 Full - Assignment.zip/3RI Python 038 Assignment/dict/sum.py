#write the python program to calculate sum of items


dict1 = {"a": 2, "b": 3 , "c": 5, "d":7 }
sum = 0 
for items in dict1.values():
    sum += items
print ("The sum of digits : ",sum)

'''
output = The sum of digits :  17
'''
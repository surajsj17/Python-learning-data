# write the program to print from 1 to entered values 

num = int(input("Enter the number :"))

counter = 1
while num >= counter :
    print (counter ,end = "  ")
    counter = counter + 1
  
  
'''
    OUTPUT 
    Enter the number : 5    
    1 2 3 4 5
'''
# write the program for adding the 2 numbers

number = 10   # static value declaration with variable
number1 = 30

result = number + number1  # addition of 2 numbers using + [Arithmetic] operator
print (result)

'''
Output - 40
'''
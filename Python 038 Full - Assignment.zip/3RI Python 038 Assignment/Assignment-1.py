#write the program to take 2 number from user and perform all arithmetic operators
# Arithmetic operators : + , - , * , /,%,//,**

#Input from user 
a = int(input("Enter the first Number : "))
b = int(input("Enter the secound Number :"))

print ()
print ("Addition" ,a+b)
print ("subtraction ",a-b)
print ("multiplication",a*b)
print("Division (quotient float)",a/b)
print("Floor Division (quotient int)",a//b)
print("exponentiation ",a**b)
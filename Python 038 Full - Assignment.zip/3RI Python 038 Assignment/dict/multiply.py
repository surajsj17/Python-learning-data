#write the program to multiple the items of dictionary

dict1 = {"a": 2, "b": 3 , "c": 5, "d":7 }
sum = 1 
for items in dict1.values():
    sum *= items
print ("The Multiple all the items  : ",sum)

'''
OUTPUT = The Multiple all the items  :  210
'''

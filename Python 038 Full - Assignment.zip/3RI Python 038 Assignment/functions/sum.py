# write the program to sum of list by using function

list  =  [10,20,30,40]

def sum():
    sum = 0
    for i in list:
        sum =sum+i
    return sum

print("The sum of list : ",sum())

'''
OUTPUT - 
The sum of list :  100

'''
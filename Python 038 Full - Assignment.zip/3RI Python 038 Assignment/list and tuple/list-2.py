# write the program to print some of digit present in list

list = [10,20,30,40]
sum = 0
for i in list:
    sum = sum + i
print (f"The sum of list : {sum}")

'''
OUTPUT = The sum of list : 100
'''
# write the program to check the give letters is vowel or not

letter = (input("Enter letters :"))

if letter == "a":
    print("letter is a vowel")
elif letter == "e":
    print("letter is a vowel")
elif letter == "i":
    print("letter is a vowel")
elif letter == "o":
    print("letter is a vowel")
elif letter == "u":
    print("letter is a vowel")
else:
    print("letter is a consonant")
    
    
'''
OUTPUT - Enter letters :a
         letter is a vowel
         
         Enter letters :q
         letter is a consonant
'''
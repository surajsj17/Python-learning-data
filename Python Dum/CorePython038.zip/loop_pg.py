# loop :
print("hello world")
#1. while :
# 1) intialize counter variable :  0 or 1
# 2) while syntax: 
# while condition(relational_oper):
#     statements (logic)
#   3)  counter variable (increment/decrement)

# wap to print hello world 10 times on console.
a = 1
while  a <=10: # true
    print(a,"hello world")
    a = a+1  # a+=1  
print("Code is done")

#  += --> Assignment ope
a = 10
print(a) # 10
a+=1   # a = a+ 1
print(a) # 11

# wap to print 0 to 20 numbers.

#  how to decrements variable value
b = 20 
print(b)
b-= 5 # b = b-5
print(b)

# 10 to 1 

c = 1
v = 10
while c <=10:
    print(v)  # 10 
    v-=1  # v = 9
    c+=1  # c =2

print("$"*100)
# 10 to 1
c = 10
while c>=1:
    print(c)
    c-=1

# wap to print even numbers between 1 to 20 int numbers.

# if..else
# while...
c = 1
while c <=20:
    if  c%2==0:  # false 
        print(c)
    c+=1 


# for loop 
# range() :  it return countable values object.
print(range(10))  # range(0,10)












#2. for  


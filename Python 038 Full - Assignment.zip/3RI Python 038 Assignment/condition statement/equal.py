# write the program to check 2 number are equal or not

num = int(input("Enter the first number :"))
num2 = int(input("Enter the second number :"))

if num == num2:
    print("Number is equal")
else:
    print ("Number is not equal")
    
'''
OUTPUT - Enter the first number :20
         Enter the second number :20
         Number is equal
'''
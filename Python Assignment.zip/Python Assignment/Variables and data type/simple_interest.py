#write the program for calculating the simple interest

# formula for calculating the interest  [principal*rate*time/100]

principal = 10.6   
rate = 35
time = 2       # put the time in years

simple_interest = principal*rate*time/100  # calculate the interest 

print ("The Simple Interest : ",simple_interest)  # print the simple interest


'''
OUTPUT - The Simple Interest :  7.42

'''